<?php include('partials/menu.php');?>

        <!Main Content >
        <div class="menu-content">
            <div class="wrapper">
            <h1>About us</h1>
        
        
      
            </div>
        </div>
<?php include('partials/footer.php'); ?>