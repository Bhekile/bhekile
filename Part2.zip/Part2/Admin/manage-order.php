<?php include('partials/menu.php'); ?>

<div class="menu-content">
    <div class="wrapper">
        <h1>Orders</h1>

        <table class="tbl-full">
                <tr>
                    <th>S.N.</th>
                    <th>Surname</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Username</th>
                    <th>Actions</th>
                </tr>

                <tr>
                    <td>1. </td>
                    <td>Bhekile</td>
                    <td> Mngwenya</td>
                    <td> bhekilemngwenya@gmail.com</td>
                    <td>
                        <a href="#"class="btn-secon">update Admin</a>
                        <a href="#"class="btn-third">Delete Admin</a>
                    </td>
                </tr>

                <tr>
                    <td>2. </td>
                    <td>Bhekile</td>
                    <td> Mngwenya</td>
                    <td> bhekilemngwenya@gmail.com</td>
                    <td>
                        <a href="#"class="btn-secon">update Admin</a>
                        <a href="#"class="btn-third">Delete Admin</a>
                    </td>
                </tr>

                <tr>
                    <td>3. </td>
                    <td>Bhekile</td>
                    <td> Mngwenya</td>
                    <td> bhekilemngwenya@gmail.com</td>
                    <td>
                        <a href="#"class="btn-secon">update Admin</a>
                        <a href="#"class="btn-third">Delete Admin</a>
                    </td>
                </tr>
            </table>
    </div>
</div>

<?php include('partials/footer.php'); ?>