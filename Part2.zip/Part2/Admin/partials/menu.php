<?php 
    include('../config/constants.php');
    include('login check.php');
?>

<html>
    <head>
        <title>BookWorm Store-Home Page</title>

        <link rel="stylesheet" href="../css/Admin.css">
    </head>

    <body>
        <!Menu Section >
        <div class="menu text-center">
            <div class="wrapper">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="manageadmin.php">About us</a></li>
                    <li><a href="manage-order.php">Order</a></li>
                    <li><a href="manage-Books.php">Books</a></li>
                    <li><a href="logout.php">My Account</a></li> 
                </ul>
            </div>
        </div>